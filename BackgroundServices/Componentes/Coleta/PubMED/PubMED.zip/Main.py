import urllib.request as urllib
import xml.etree.ElementTree as xml
import pprint

from Modulos.ComponenteColeta import ComponenteColeta

class Main(ComponenteColeta):

    def extract(self):

        return

    def parse(self):
        # print("Parse")
        return

    def save(self):

        return