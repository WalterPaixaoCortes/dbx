from .Componente import *

class Main(ComponenteColeta):

    def __init__(self, d, t):
        Componente.__init__(self, d)
        return

    def extract(self):
        Componente.__init__(self, d)
        return

    def parse(self):
        Componente.__init__(self, d)
        return

    def save(self):
        Componente.__init__(self, d)
        return